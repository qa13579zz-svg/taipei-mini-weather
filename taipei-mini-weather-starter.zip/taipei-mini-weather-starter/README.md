# Taipei Mini Weather

An iPhone app + WidgetKit extension starter for a miniature Taipei city weather widget.

## Status
This is a starter project structure, not yet a complete signed iOS app. It needs an Apple developer signing/build setup and weather API integration before installation on an iPhone.

## Planned features
- Small square Home Screen widget
- Taipei 101 miniature-city visual
- Current weather and local time
- Sunrise and sunset
- WidgetKit timeline refreshes (system-managed; not continuous animation)

## Privacy and secrets
Never commit API keys, passwords, certificates, or personal information.
