# Setup checklist

These files are Swift source starters. They are not a complete Xcode project by themselves.

## Required Xcode targets
Create an iOS app target:
- Product name: TaipeiMiniWeather
- Add `TaipeiMiniWeatherApp.swift` and `TaipeiMiniScene.swift`

Create a Widget Extension target:
- Product name: TaipeiMiniWeatherWidgetExtension
- Add `TaipeiMiniWeatherWidget.swift` and `TaipeiMiniScene.swift`
- Ensure the widget target includes `TaipeiMiniScene.swift` too, since the widget uses that view.

Set iOS deployment target to iOS 17 or later because `.containerBackground(_:for:)` is used.
Set unique bundle identifiers for both targets. Enable automatic signing only in a trusted build environment with your Apple account.

## Caveat
A GitHub repository does not build/sign the app by itself. A macOS/Xcode or compatible cloud build pipeline is still required. Do not upload certificates, provisioning profiles, API keys, or passwords to this repository.
