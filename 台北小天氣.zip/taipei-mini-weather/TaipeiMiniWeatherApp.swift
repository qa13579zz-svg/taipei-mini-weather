import SwiftUI

@main
struct TaipeiMiniWeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(red: 0.96, green: 0.93, blue: 0.86).ignoresSafeArea()
            VStack(spacing: 16) {
                TaipeiMiniScene()
                    .frame(height: 280)
                    .clipShape(RoundedRectangle(cornerRadius: 24))
                Text("TAIPEI")
                    .font(.system(size: 28, weight: .semibold, design: .serif))
                    .tracking(4)
                Text("Miniature City Weather")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(.secondary)
                Text("Starter preview · weather data not connected")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .padding(24)
        }
    }
}
