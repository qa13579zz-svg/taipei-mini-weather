import SwiftUI

/// Stylized SwiftUI illustration used by the app and widget.
/// Replace with a rendered diorama image later for a more photorealistic result.
struct TaipeiMiniScene: View {
    var compact: Bool = false

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.94, green: 0.79, blue: 0.57),
                        Color(red: 0.97, green: 0.91, blue: 0.78),
                        Color(red: 0.80, green: 0.84, blue: 0.75)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                Circle()
                    .fill(Color(red: 1.0, green: 0.88, blue: 0.62).opacity(0.8))
                    .frame(width: h * 0.22)
                    .position(x: w * 0.78, y: h * 0.2)

                // Distant hills
                Ellipse()
                    .fill(Color(red: 0.48, green: 0.59, blue: 0.48).opacity(0.65))
                    .frame(width: w * 0.95, height: h * 0.28)
                    .position(x: w * 0.2, y: h * 0.72)
                Ellipse()
                    .fill(Color(red: 0.40, green: 0.53, blue: 0.43).opacity(0.65))
                    .frame(width: w * 0.95, height: h * 0.30)
                    .position(x: w * 0.85, y: h * 0.72)

                // City base
                Path { p in
                    p.move(to: CGPoint(x: 0, y: h * 0.76))
                    p.addLine(to: CGPoint(x: w, y: h * 0.70))
                    p.addLine(to: CGPoint(x: w, y: h))
                    p.addLine(to: CGPoint(x: 0, y: h))
                    p.closeSubpath()
                }
                .fill(Color(red: 0.77, green: 0.68, blue: 0.52))

                // Taipei 101
                VStack(spacing: 0) {
                    Rectangle().fill(Color(red: 0.26, green: 0.43, blue: 0.42)).frame(width: w * 0.035, height: h * 0.045)
                    ForEach(0..<7, id: \.self) { i in
                        let width = w * (0.12 - Double(i) * 0.009)
                        ZStack {
                            Rectangle().fill(Color(red: 0.28, green: 0.47, blue: 0.45))
                            Rectangle().fill(Color(red: 0.88, green: 0.79, blue: 0.61)).frame(height: 1).offset(y: -h * 0.025)
                            Rectangle().fill(Color(red: 0.88, green: 0.79, blue: 0.61)).frame(height: 1).offset(y: h * 0.025)
                        }
                        .frame(width: width, height: h * 0.065)
                    }
                    Rectangle().fill(Color(red: 0.25, green: 0.42, blue: 0.41)).frame(width: w * 0.045, height: h * 0.035)
                }
                .position(x: w * 0.52, y: h * 0.49)

                // Surrounding blocks
                building(width: w * 0.12, height: h * 0.28, color: Color(red: 0.72, green: 0.55, blue: 0.39))
                    .position(x: w * 0.20, y: h * 0.77)
                building(width: w * 0.13, height: h * 0.34, color: Color(red: 0.84, green: 0.72, blue: 0.52))
                    .position(x: w * 0.79, y: h * 0.75)
                building(width: w * 0.10, height: h * 0.22, color: Color(red: 0.66, green: 0.60, blue: 0.48))
                    .position(x: w * 0.91, y: h * 0.81)

                // Foreground street
                Path { p in
                    p.move(to: CGPoint(x: w * 0.32, y: h * 0.80))
                    p.addLine(to: CGPoint(x: w * 0.70, y: h * 0.77))
                    p.addLine(to: CGPoint(x: w * 0.92, y: h))
                    p.addLine(to: CGPoint(x: w * 0.10, y: h))
                    p.closeSubpath()
                }
                .fill(Color(red: 0.36, green: 0.38, blue: 0.34))
                Path { p in
                    p.move(to: CGPoint(x: w * 0.50, y: h * 0.86))
                    p.addLine(to: CGPoint(x: w * 0.50, y: h * 0.90))
                    p.move(to: CGPoint(x: w * 0.50, y: h * 0.93))
                    p.addLine(to: CGPoint(x: w * 0.50, y: h * 0.97))
                }
                .stroke(Color.white.opacity(0.7), style: StrokeStyle(lineWidth: max(1, w * 0.006), lineCap: .round))

                // Warm miniature highlights
                Ellipse()
                    .fill(Color.white.opacity(0.15))
                    .frame(width: w * 0.55, height: h * 0.05)
                    .blur(radius: 5)
                    .position(x: w * 0.45, y: h * 0.67)
            }
            .clipped()
        }
    }

    @ViewBuilder
    private func building(width: CGFloat, height: CGFloat, color: Color) -> some View {
        VStack(spacing: 0) {
            Rectangle().fill(color.opacity(0.85)).frame(height: height * 0.08)
            Rectangle().fill(color)
                .overlay(alignment: .top) {
                    VStack(spacing: height * 0.035) {
                        ForEach(0..<4, id: \.self) { _ in
                            HStack(spacing: width * 0.12) {
                                ForEach(0..<2, id: \.self) { _ in
                                    Rectangle()
                                        .fill(Color(red: 0.93, green: 0.82, blue: 0.61).opacity(0.9))
                                        .frame(width: width * 0.16, height: height * 0.07)
                                }
                            }
                        }
                    }
                    .padding(.top, height * 0.06)
                }
        }
        .frame(width: width, height: height)
    }
}
