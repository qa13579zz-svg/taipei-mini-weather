import WidgetKit
import SwiftUI

struct TaipeiWeatherEntry: TimelineEntry {
    let date: Date
    let temperature: String
    let condition: String
    let cityTime: String
}

struct TaipeiWeatherProvider: TimelineProvider {
    func placeholder(in context: Context) -> TaipeiWeatherEntry {
        TaipeiWeatherEntry(date: .now, temperature: "26°", condition: "Partly cloudy", cityTime: "06:50")
    }

    func getSnapshot(in context: Context, completion: @escaping (TaipeiWeatherEntry) -> Void) {
        completion(TaipeiWeatherEntry(date: .now, temperature: "26°", condition: "Partly cloudy", cityTime: Date.now.formatted(date: .omitted, time: .shortened)))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<TaipeiWeatherEntry>) -> Void) {
        // Placeholder values only. WidgetKit controls actual refresh timing.
        let entry = TaipeiWeatherEntry(
            date: .now,
            temperature: "26°",
            condition: "Partly cloudy",
            cityTime: Date.now.formatted(date: .omitted, time: .shortened)
        )
        completion(Timeline(entries: [entry], policy: .after(Date.now.addingTimeInterval(60 * 60))))
    }
}

struct TaipeiMiniWeatherWidgetView: View {
    var entry: TaipeiWeatherProvider.Entry

    var body: some View {
        ZStack(alignment: .topLeading) {
            TaipeiMiniScene(compact: true)
            LinearGradient(colors: [.black.opacity(0.48), .clear, .black.opacity(0.05)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 2) {
                HStack(alignment: .firstTextBaseline) {
                    Text("TAIPEI")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(1.4)
                    Spacer(minLength: 2)
                    Text(entry.cityTime)
                        .font(.system(size: 9, weight: .semibold, design: .rounded))
                }
                Text(entry.temperature)
                    .font(.system(size: 27, weight: .light, design: .rounded))
                Text(entry.condition)
                    .font(.system(size: 9, weight: .medium))
            }
            .foregroundStyle(.white)
            .padding(10)
        }
        .containerBackground(Color(red: 0.89, green: 0.80, blue: 0.64), for: .widget)
    }
}

@main
struct TaipeiMiniWeatherWidget: Widget {
    let kind = "TaipeiMiniWeatherWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TaipeiWeatherProvider()) { entry in
            TaipeiMiniWeatherWidgetView(entry: entry)
        }
        .configurationDisplayName("Taipei Mini Weather")
        .description("A miniature Taipei skyline with local time and weather.")
        .supportedFamilies([.systemSmall])
    }
}
