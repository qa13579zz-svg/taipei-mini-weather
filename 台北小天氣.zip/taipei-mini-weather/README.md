# Taipei Mini Weather — iOS Widget starter

This repository is a starter scaffold for an iPhone app with a WidgetKit home-screen widget showing a miniature Taipei skyline.

## Important status
This is source code, not an installable/signable iOS app yet. It must be built with Xcode/macOS or a compatible cloud macOS build service, and signed with an Apple development team before installing on a physical iPhone.

## What is included
- SwiftUI app entry point
- WidgetKit extension with a small square widget
- A simple SwiftUI miniature Taipei illustration (Taipei 101 and skyline)
- Placeholder weather data, clearly marked for replacement by a real weather API

## Not included yet
- Apple signing credentials / provisioning
- A real weather API integration
- Cloud build workflow configured for this repository

## Suggested next steps
1. Commit these files to your GitHub repository.
2. Open the repository in a cloud macOS build environment or on a Mac with Xcode.
3. Create/configure an iOS app target and a Widget Extension target named `TaipeiMiniWeather` and `TaipeiMiniWeatherWidgetExtension`.
4. Set a unique bundle identifier for the app and widget extension, and configure signing.
5. Replace placeholder weather data with a weather API and review API terms.
6. Build, sign, and install on an iPhone.

The Swift files here are starter source files. A plain upload to GitHub does not create an installable app.
